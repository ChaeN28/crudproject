package com.shinhan.emp;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class EmpController {

	static Scanner sc = new Scanner(System.in);
	static EmpService empService = new EmpService();
	
	public static void main(String[] args) {
		boolean isStop = false;
		while(!isStop) {
			menuDisplay();
			int job = sc.nextInt();
			switch(job) {
				case 1->{f_selectAll();}
				case 2->{f_selectByEmpId();}
				case 3->{f_selectByDept();}
				case 4->{f_selectByJob();}
				case 5->{f_selectByJobAndDept();}
				case 6->{f_selectByCondition();}
				case 7->{f_empDeleteById();}
				case 8 ->{f_empInsert();}
				case 9->{f_empUpdate();}
				case 10->{sp_empinfo2(); }
				case 99->{isStop=true;}
			}
		}
		System.out.println("========Good Bye========");
	}

	
	private static void sp_empinfo2() {
		System.out.print("조회할 직원ID>>");
		int employee_id = sc.nextInt();
		EmpDTO emp = empService.execute_sp(employee_id);
		String message = "해당직원은 존재하지않습니다.";
		if(emp!=null) {
			message = emp.getEmail() + "---" + emp.getSalary();
		}
		
		EmpView.display(message);
		
	}


	private static void f_empUpdate() {
		System.out.print("수정할 직원ID>>");
		int empid = sc.nextInt();
		EmpDTO exist_emp = empService.selectByEmpId(empid);
		if(exist_emp == null) {
			EmpView.display("존재하지않는 직원입니다.");
			return;
		}
		EmpView.display("=========존재하는 직원정보입니다.========");
		EmpView.display(exist_emp);
		int result = empService.empUpdate(makeEmp(empid));
		EmpView.display(result +"건수정");
		
	}


	private static void f_empInsert() {
		System.out.print("추가할 직원ID>>");
		int empid = sc.nextInt();
		
		int result = empService.empInsert(makeEmp2(empid));
		
		EmpView.display(result + "건 입력"); 
		
	}

	static EmpDTO makeEmp(int empid) {
		System.out.print("FIRST_NAME>>");
		String fname = sc.next();
		
		System.out.print("LAST_NAME>>");
		String lname = sc.next();
		
		System.out.print("EMAIL>>");
		String email = sc.next();
		
		System.out.print("PHONE_NUMBER>>");
		String pnum = sc.next();

		System.out.print("HIRE_DATE>>");
		String hdate =  sc.next();  
		Date hire_date = null;
		if(!hdate.equals("0")) {
			hire_date  = DateUtil.convertToSQLDate(DateUtil.ConvertToDate(hdate));
		}
		
		System.out.print("(FK:IT_PROG)JOB_ID>>");
		String jobid  = sc.next();
		
		System.out.print("SALARY>>");
		Double salary  = sc.nextDouble();
		
		System.out.print("COMMISSION_PCT(0.2)>>");
		Double comm  = sc.nextDouble();
		
		System.out.print("MANAGER_ID(FK:100)>>");
		Integer mid  = sc.nextInt();
		
		System.out.print("DEPARTMENT_ID(FK:60,90)>>");
		Integer did  = sc.nextInt();
		
		
		if(fname.equals("0")) fname = null;
		if(lname.equals("0")) lname = null;
		if(email.equals("0")) email = null;
		if(pnum.equals("0")) pnum = null;
		if(jobid.equals("0")) jobid = null;
		if(salary == 0) jobid = null;
		if(comm == 0) comm = null;
		if(mid == 0) mid = null;
		if(did == 0) did = null;
		

		EmpDTO Emp = EmpDTO.builder()
				.employee_id(empid)
				.first_name(fname)
				.last_name(lname)
				.email(email)
				.phone_number(pnum)
				.hire_date(hire_date)
				.job_id(jobid)
				.salary(salary)
				.commission_pct(comm)
				.manager_id(mid)
				.department_id(did)
				.build();
		
		System.out.println(Emp);
		
		return Emp;
	}
	
	static EmpDTO makeEmp2(int empid) {
		System.out.print("FIRST_NAME>>");
		String fname = sc.next();
		System.out.print("LAST_NAME>>");
		String lname = sc.next();
		System.out.print("EMAIL>>");
		String email = sc.next();
		System.out.print("PHONE_NUMBER>>");
		String pnum = sc.next();
		System.out.print("HIRE_DATE>>");
		String hdate =  sc.next();    
		Date hire_date  =DateUtil.convertToSQLDate(DateUtil.ConvertToDate(hdate));
		System.out.print("(FK:IT_PROG)JOB_ID>>");
		String jobid  = sc.next();
		System.out.print("SALARY>>");
		double salary  = sc.nextDouble();
		System.out.print("COMMISSION_PCT(0.2)>>");
		double comm  = sc.nextDouble();
		System.out.print("MANAGER_ID(FK:100)>>");
		int mid  = sc.nextInt();
		System.out.print("DEPARTMENT_ID(FK:60,90)>>");
		int did  = sc.nextInt();

		EmpDTO Emp = EmpDTO.builder()
				.employee_id(empid)
				.first_name(fname)
				.last_name(lname)
				.email(email)
				.phone_number(pnum)
				.hire_date(hire_date)
				.job_id(jobid)
				.salary(salary)
				.commission_pct(comm)
				.manager_id(mid)
				.department_id(did)
				.build();
		return Emp;
	}

	private static void f_empDeleteById() {
		System.out.print("삭제할 직원의 ID>>");
		int empid = sc.nextInt();
		int result = empService.empDeleteById(empid);
		EmpView.display(result + "건 삭제");
		
	}


	private static void f_selectByCondition() {
		//  =부서, like 직책, >=급여, >=입사일
		System.out.print("조회할 부서>>");
		int deptid  = sc.nextInt();
		System.out.print("조회할 직책ID>>");
		String jobid  = sc.next();
		System.out.print("조회할 salary(이상)>>");
		int  salary = sc.nextInt();
		System.out.println("조회할 입사일(yyy-MM-dd이상)>>");
		String hdate = sc.next();
		
		List<EmpDTO> emplist = empService.selectByCondition(deptid,jobid,salary,hdate);
		EmpView.display(emplist);
	}


	private static void f_selectByJobAndDept() {
		System.out.print("조회할 직책ID,부서ID>>");//IT_PROG,60
		String data = sc.next();
		String[] arr = data.split(",");
		String jobid  = arr[0];
		int deptid = Integer.parseInt(arr[1]);
		List<EmpDTO> emplist = empService.selectByJobAndDept(jobid, deptid);
		EmpView.display(emplist);
		
	}


	private static void f_selectByJob() {
		System.out.print("조회할 직책ID>>");
		String jobid  = sc.next();
		List<EmpDTO> emplist = empService.selectByJob(jobid);
		EmpView.display(emplist);
		
	}


	private static void f_selectByDept() {
		System.out.print("조회할 부서ID>>");
		int deptid = sc.nextInt();
		List<EmpDTO> emplist = empService.selectByDept(deptid);
		EmpView.display(emplist);
	}


	private static void f_selectByEmpId() {
		System.out.print("조회할 ID>>");
		int empid = sc.nextInt();
		EmpDTO emp = empService.selectByEmpId(empid);
		EmpView.display(emp);
		
	}

	private static void f_selectAll() {
		List<EmpDTO> emplist = empService.selectAll();
		EmpView.display(emplist);
	}

	private static void menuDisplay() {
		System.out.println("-------------------");
		System.out.println("1.모두조회 2.조회(직원번호) 3.조회(부서) 4.조회(직책) 5.조건조회(부서,직책) 6.조건조회 7.delete 8.insert 9.update  99.끝");
		System.out.println("-------------------");
		System.out.print("작업선택>");
		
		
	}

}
